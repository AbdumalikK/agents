<?php
session_start();
include 'function.php';
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $row = airbac($id);
}
if(isset($_POST['insert'])){
    $a = $_POST['jam_suma'];
    $b = $_POST['ber_suma'];
    $c = $_POST['sklad_suma'];
    $d = addslashes($_POST['komment']);
    $s = inset($a, $b, $c, $d, $id);
    if($s){
        header("Location: agent.php?id=$_SESSION[id]");
    }
    
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    <title>Original Trombones</title>
</head>
<body>
    <div class="card bg-light m-5" style="max-width: 100%;">
        <div class="card-body">
            <h5 class="card-title"></h5>
            <p class="card-text">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Жами сўмма</th>
                            <th scope="col">Берган пули</th>                            
                            <th scope="col">Складдан жами ҚАРЗИ</th>
                            <th scope="col">Komment</th>
                        </tr>
                    </thead>
                    <tbody>
                      <form method="POST">
                          <?php while($sr = $row->fetch_array()):?>
                            <tr>
                                <td>
                                    <div class="mb-3">
                                        <input type="number" value="<?=$sr['jami_suma']?>" name="jam_suma" class="form-control">
                                    </div>
                                </td>
                                <td>
                                    <div class="mb-3">
                                        <input type="number" value="<?=$sr['bergan_suma']?>" name="ber_suma" class="form-control">
                                    </div>
                                </td>
                                <td>
                                    <div class="mb-3">
                                        <input type="number" value="<?=$sr['bazaviy_suma']?>" name="sklad_suma" class="form-control">
                                    </div>
                                </td>
                                <td>
                                    <div class="mb-3">
                                        <input type="text" value="<?=$sr['komment']?>" class="form-control"
                                        name="komment" ></input>
                                    </div>
                                </td>
                                <td>
                                    <button type="submit" name="insert" class="btn btn-success"><i class="fa fa-check"></i></button>
                                </td>
                            </tr>
                            <?php endwhile;?>
                      </form>
                </table>
            </p>
    </div>

</body>
</html>