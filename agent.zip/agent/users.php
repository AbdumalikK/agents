<?php
$avtomobil = $_POST['avto'];

$db = new mysqli('localhost','root','','agent');
$rv = $db->query("SELECT * FROM agents WHERE avtomobil = '{$avtomobil}'");
while($row = $rv->fetch_array()){
    echo '<p class="alert alert-danger">'.'Hozirda'.' '.$row['avtomobil'].' '.'avtomobil'.' '.'band'.'</p>';
}
?>
