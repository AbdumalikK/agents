<?php
function connect(){
    $db = new mysqli('localhost','root','','agent');
    return $db;
}
function name($id)
{
    $db = connect();
    $get = $db->query("SELECT * FROM agents WHERE id='{$id}'");
    while($sv = $get->fetch_array()){
        echo $sv['name'].' '.$sv['telefon'];
    }
}
function read()
{
    $db = connect();
    $get = $db->query("SELECT * FROM agents WHERE status = '1'");
    while($row = $get->fetch_array()){
        echo "<tr>";
            echo "<td>$row[name]</td>";
            echo "<td>$row[telefon]</td>";
            echo "<td>$row[avtomobil]</td>";
            echo "<td>";
                echo "<a href='agent.php?id={$row['id']}' class='btn btn-info'><i class='fa fa-user'></i></a>";
                echo "<a href='del.php?id={$row['id']}' class='btn btn-danger' style='margin-left:10px'><i class='fa fa-trash'></i></a>";
            echo "</td>";
        echo "</tr>";
        
    }
}

function insert($name,$avto,$tel_nomer)
{
    $db = connect();
    $db->query("INSERT INTO `agents` (id, name, telefon, avtomobil) VALUES (NULL, '{$name}', '{$tel_nomer}', '{$avto}')");
    return $db;
}
function inserting($a,$b,$c,$d,$id){
    $db = connect();
    $db->query("INSERT INTO `agents_view` (id, jami_suma, bergan_suma, bazaviy_suma, komment, vaqt, agents_id) VALUES (NULL, '{$a}', '{$b}', '{$c}', '{$d}', NOW(), '{$id}')");
    return $db;
}

function getreading($d)
{
    $db = connect();
    $red = $db->query("SELECT * FROM agents_view WHERE agents_id='{$d}' AND status = 1");
    while($r = $red->fetch_array()){
        echo "<tr>";
            echo "<td>$r[vaqt]</td>";
            echo "<td>$r[jami_suma] сум</td>";
            echo "<td>$r[bergan_suma] сум</td>";
            echo "<td>$r[bazaviy_suma] сум</td>";
            echo "<td>$r[komment]</td>";
            echo "<td>";
            echo "<a href='update.php?id=$r[id]' name='update' class='btn btn-info'><i class='fa fa-pencil'></i></a>";
            echo "<a href='delete.php?id=$r[id]' class='btn btn-danger' style='margin-left:10px'><i class='fa fa-trash'></i></a>";
             echo "</td>";
        echo "</tr>";
    }
    
}
function airbac($id)
{
    $db = connect();
    $sd = $db->query("SELECT * FROM agents_view WHERE id='{$id}'");
    return $sd;
}

function inset($a,$b,$c,$d,$id)
{
    $db = connect();
    $db->query("UPDATE agents_view SET jami_suma = {$a}, bergan_suma = {$b}, bazaviy_suma = {$c}, komment = '{$d}', vaqt = NOW() WHERE id = $id");
    return $db;
}

function delete($d)
{
    $db = connect();
    $db->query("UPDATE agents_view SET status = 0 WHERE id = '{$d}'");
    return $db;
}

function dele($r){
    $db = connect();
    $db->query("UPDATE agents SET status = '0' WHERE id = '{$r}'");
    return $db;
}

?>