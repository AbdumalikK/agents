<?php
include 'function.php';
    $id = $_GET['id'];
    dele($id);
    header("Location: index.php")
?>