-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июн 12 2021 г., 14:58
-- Версия сервера: 5.6.47
-- Версия PHP: 7.3.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `agent`
--

-- --------------------------------------------------------

--
-- Структура таблицы `agents`
--

CREATE TABLE `agents` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `telefon` varchar(255) NOT NULL,
  `avtomobil` varchar(255) NOT NULL,
  `status` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `agents`
--

INSERT INTO `agents` (`id`, `name`, `telefon`, `avtomobil`, `status`) VALUES
(1, 'Qobiljon', '+998994060828', '40D772AA', '1');

-- --------------------------------------------------------

--
-- Структура таблицы `agents_view`
--

CREATE TABLE `agents_view` (
  `id` int(10) UNSIGNED NOT NULL,
  `jami_suma` float NOT NULL,
  `bergan_suma` float NOT NULL,
  `bazaviy_suma` float NOT NULL,
  `komment` text NOT NULL,
  `vaqt` datetime NOT NULL,
  `status` enum('1','0') NOT NULL,
  `agents_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `agents_view`
--

INSERT INTO `agents_view` (`id`, `jami_suma`, `bergan_suma`, `bazaviy_suma`, `komment`, `vaqt`, `status`, `agents_id`) VALUES
(1, 500000, 250000, 250000, '250000 qarz bo\'ldi', '2021-06-12 16:03:17', '1', 1),
(2, 500000, 250000, 250000, '250000 qarz bo\'ldi', '2021-06-12 16:31:19', '1', 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `agents`
--
ALTER TABLE `agents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `avtomobil` (`avtomobil`);

--
-- Индексы таблицы `agents_view`
--
ALTER TABLE `agents_view`
  ADD PRIMARY KEY (`id`),
  ADD KEY `agents_id` (`agents_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `agents`
--
ALTER TABLE `agents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `agents_view`
--
ALTER TABLE `agents_view`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `agents_view`
--
ALTER TABLE `agents_view`
  ADD CONSTRAINT `agents_view_ibfk_1` FOREIGN KEY (`agents_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
