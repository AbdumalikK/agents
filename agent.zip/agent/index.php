<?php
    include 'function.php';
    if(isset($_POST['clas'])){
        $name = addslashes($_POST['name']);
        $avto = $_POST['avto'];
        $tel_nomer = $_POST['tel_nomer'];
        insert($name,$avto,$tel_nomer);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4"
    crossorigin="anonymous"></script>
    <title>Agents</title>
</head>
<body>
<div class="container">
    
    <div class="card text-dark bg-light m-5">
        <div class="card-header">
            <!-- <div class="dropdown d-inline">
                <button class="btn btn-success dropdown-toggle float-end" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
                    aria-expanded="false">
                    Агентлар
                </button> -->
                <!-- <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                    <li><a class="dropdown-item" href="#">Улугбек</a></li>
                    <li><a class="dropdown-item" href="#">Улугбек</a></li>
                    <li><a class="dropdown-item" href="#">Улугбек</a></li>
                </ul> -->
            <!-- </div> -->
            <button type="button" class="btn btn-primary float-end me-2" data-bs-toggle="modal" data-bs-target="#exampleModal"
                data-bs-whatever="@mdo">Агент киритиш</button>
        </div>
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Исими</th>
                        <th>Телефон номери</th>
                        <th>Автомобил</th>
                    </tr>
                </thead>
                <tbody>
                    <?=read();?>
                </table>
            
        </div>
    </div>
</div>    


<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Агент киритиш</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="" method="POST">
                    <div class="mb-3">
                        <label for="recipient-name" class="col-form-label">Исми:</label>
                        <input type="text" name="name" class="form-control" id="recipient-name" required>
                    </div>
                    <div class="mb-3">
                        <div id="s"></div>
                        <label for="message-text" class="col-form-label">Avtomobil</label>
                        <input type="text" name="avto" class="form-control" id="avto" required></input>
                    </div>
                    <div class="mb-3">
                        <label for="message-text" class="col-form-label">Телефон номер:</label>
                        <input type="text" name="tel_nomer" class="form-control" id="message-text" required></input>
                    </div>
                    <div class="mb-3">
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Бекор килиш</button>
                            <button type="submit" name="clas" class="btn btn-primary">Саклаш</button>   
                        </div>
                    </div>
                </form>
            </div>
           
        </div>
    </div>
</div>
<script src="jquery-3.6.0.min.js"></script>
<script src="ajax.js"></script>
</body>
</html>