<?php
session_start();
$_SESSION['id'] = $_GET['id'];
include 'function.php';
$i = $_GET['id'];
if(isset($_POST['ddb'])){
    $j_suma = $_POST['j_suma'];
    $b_suma = $_POST['b_suma'];
    $c_suma = $_POST['c_suma'];
    $koment = addslashes($_POST['komment']);
    inserting($j_suma,$b_suma,$c_suma,$koment,$i);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    <title>Original Trombones</title>
</head>
<body>
    <div class="card bg-light m-5" style="max-width: 100%;">
        <div class="card-header text-center"><?php if(isset($_GET['id'])){
            name($_GET['id']);
        } ?></div>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal"
                data-bs-whatever="@getbootstrap">Махсулот кошиш</button>
            
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Малумот критинг</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form method="POST">
                                <div class="mb-3">
                                    <label for="recipient-name" class="col-form-label">Жами сўмма:</label>
                                    <input type="number" name="j_suma" class="form-control" id="recipient-name">
                                </div>
                                <div class="mb-3">
                                    <label for="recipient-name" class="col-form-label">Берган пули:</label>
                                    <input type="number" name="b_suma" class="form-control" id="recipient-name">
                                </div>
                                <div class="mb-3">
                                    <label for="recipient-name" class="col-form-label">Складдан жами ҚАРЗИ:</label>
                                    <input type="number" name="c_suma" class="form-control" id="recipient-name">
                                </div>
                                <div class="mb-3">
                                    <label for="message-text" class="col-form-label">Komment:</label>
                                    <textarea class="form-control" name="komment" id="message-text"></textarea>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Бекор килиш</button>
                                    <button type="submit" name="ddb" class="btn btn-primary">Саклаш</button>
                                </div>
                            </form>
                        </div>
                        
                    </div>
                </div>
            </div>
        <div class="card-body">
            <h5 class="card-title"></h5>
            <p class="card-text">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Сана</th>
                            <th scope="col">Жами сўмма</th>
                            <th scope="col">Берган пули</th>                            
                            <th scope="col">Складдан жами ҚАРЗИ</th>
                            <th scope="col">Komment</th>
                        </tr>
                    </thead>
                    <tbody>
                       <?php if(isset($_GET['id'])):?>
                            <?php getreading($_GET['id']) ?>
                       <?php endif;?>
                </table>
            </p>
    </div>

</body>
</html>