$(function(){
    $("#avto").blur(function(e){
        e.preventDefault();
        $.ajax({
            url: 'users.php',
            type: 'POST',
            data: {avto:$('#avto').val()},
            success: function(res){
                if(res){
                    $('#avto').css({
                        border:'1px solid red',
                    });
                    $('#s').html(res);
                }
            }
        });
    });
});
