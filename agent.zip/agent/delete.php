<?php
include 'function.php';
session_start();
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $del = delete($id);
    if($del){
        header("Location: agent.php?id=$_SESSION[id]");
    }
}
    

?>